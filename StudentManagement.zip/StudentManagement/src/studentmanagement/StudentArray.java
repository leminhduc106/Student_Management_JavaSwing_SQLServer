/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentmanagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;

/**
 *
 * @author lemin
 */
public class StudentArray {
    private static ArrayList<Student> listStudent;

    Connection conn = null;
    PreparedStatement sttm = null;
    /**
     * Default Constructor
     */
    public StudentArray() {
        listStudent = new ArrayList<Student>();
    }

    /**
     * Copy Constructor
     * @param students
     */
    public StudentArray(StudentArray students) {
        for(int i = 0; i < students.listStudent.size(); i++) {
            (listStudent.get(i)).setId((students.listStudent.get(i)).getId());
            (listStudent.get(i)).setName((students.listStudent.get(i)).getName());
            (listStudent.get(i)).setGpa((students.listStudent.get(i)).getGpa());
            (listStudent.get(i)).setImage((students.listStudent.get(i)).getImage());
            (listStudent.get(i)).setAddress((students.listStudent.get(i)).getAddress());
            (listStudent.get(i)).setNotes((students.listStudent.get(i)).getNotes());
        }
    }
    /**
     * Check if listStudent is Empty or not
     * @return True if listStudent is empty
     */
    public boolean isEmptyList() {
        return (listStudent.size() == 0);
    }

    /**
     * Check if Student's ID is unique or not
     * @param id
     * @return True if ID is already existed
     */
    public static boolean CheckUniqueID(final String id) {
        for (Student student : listStudent) {
            if (id.equalsIgnoreCase(student.getId()))
                return true;
        }
        return false;
    }

    /**
     * Add new Student
     */
    public int addStudent(Student st) {
        try {
             if (CheckUniqueID(st.getId()) == false) {
                listStudent.add(st);
                System.out.println("Add student successful");
                return 1;
             }
        }catch(Exception e) {
            System.out.println("(!) Error: " + e.toString());
        }
        return -1;
    }
    
    /**
     * Update Student information
     */
    public int updateStudentInfo(Student st) {

        //Update Student info process
        if (CheckUniqueID(st.getId()) == true) {
            for(int i = 0; i < listStudent.size(); i++) {
                if((st.getId()).equalsIgnoreCase(listStudent.get(i).getId())) {
                    (listStudent.get(i)).setId(st.getId());
                    (listStudent.get(i)).setName(st.getName());
                    (listStudent.get(i)).setGpa(st.getGpa());
                    (listStudent.get(i)).setImage(st.getImage());
                    (listStudent.get(i)).setAddress(st.getAddress());
                    (listStudent.get(i)).setNotes(st.getNotes());
                }
            }
            return 1;
        }
        else {
            System.out.println("(i) Student ID does not exist");
            return -1;
        }
    }
    
    /**
     * Delete a Student
     */
    public int deleteStudent(String id) {
        //Delete Student process
        if (CheckUniqueID(id) == true) {
            for(int i = 0; i < listStudent.size(); i++) {
                if(id.equalsIgnoreCase(listStudent.get(i).getId()))
                    listStudent.remove(i);
            }
            return 1;

        } else {
            System.out.println("(i) Student ID does not exist");
        }
        return -1;
    }
    
    public int deleteAll() {
        try{
            listStudent.clear();

            if (listStudent.isEmpty()) {
                System.out.println("(i) Delete all student successful");
                return 1;
            } else {
                System.out.println("(i) Delete failed!");
            }
        }catch(Exception e) {
            System.out.println("Error: " + e.toString());
        }
        return -1;
    }
    
    public List<Student> getAllStudent() {
        return listStudent;
    }
    
    //Find a student by ID  
    public Student findStudentByID(String id) {
        try {
            for (Student student : listStudent) {
                if (id.equalsIgnoreCase(student.getId()))
                    return student;
            }
        } catch(Exception e) {
            System.out.println("(!) Error: " + e.toString());
        }
        return null;
    }
    
    /**
     * Sort Student list ascending by ID
     * @param listStudent
     */
    public static void sortIdAscending(final ArrayList<Student> listStudent) {
        Collections.sort(listStudent, new Comparator<Student>() {
            @Override
            public int compare(final Student st1, final Student st2) {
                return (st1.getId()).compareTo(st2.getId());
            }
        });
    }

    /**
     * Sort Student list ascending by gpa
     * @param listStudent
     */
    public static void sortGpaAscending(final ArrayList<Student> listStudent) {
        Collections.sort(listStudent, new Comparator<Student>() {
            @Override
            public int compare(final Student st1, final Student st2) {
                return Float.compare(st1.getGpa(), st2.getGpa());
            }
        });
    }
    
    public List<Student> sortByID() {
        sortIdAscending(listStudent);
        return listStudent;
    }
    
    public List<Student> sortByGpa() {
        sortGpaAscending(listStudent);
        return listStudent;
    }
    
    public void resetDB() {
        try{
            String strsql = "delete from Students";
            conn = DatabaseHelper.getDBConnect();
            sttm = conn.prepareStatement(strsql);
            if(sttm.executeUpdate() > 0) {
                System.out.println("Reset DB Successful!");
            }
        }catch(Exception e) {
            System.out.println("(!) Error:" + e.toString());
        }
    }
    
    /**
     * Save student list to database
     * @return 1 if save successful and -1 if save unsuccessful
     */
    public int saveToDB() {
        resetDB();
        try {
            String strsql = "insert Students(ID, Name, Gpa, Image, Address, Notes) " 
                    + "values(?,?,?,?,?,?)";
            conn = DatabaseHelper.getDBConnect();
            sttm = conn.prepareStatement(strsql);
            
            for(Student st : listStudent) {
                sttm.setString(1, st.getId());
                sttm.setString(2, st.getName());
                sttm.setFloat(3, st.getGpa());
                sttm.setString(4, st.getImage());
                sttm.setString(5, st.getAddress());
                sttm.setString(6, st.getNotes());
            
                if(sttm.executeUpdate() > 0) {
                    System.out.println("Insert Successful!");
                }
            }
            return 1;
            
        } catch (Exception e) {
            System.out.println("(!) Error: " + e.toString());
        }
        
        finally {
            try {
                sttm.close();
                conn.close();
            } catch (Exception e) {
            }
        }
        return -1;
    }
    
    public int loadFromDB() {
        Statement sttm = null;
        ResultSet rs = null;
        try {
            String strsql = "select * from Students";
            conn = DatabaseHelper.getDBConnect();
            sttm = conn.createStatement();
            rs = sttm.executeQuery(strsql);
            
            while(rs.next()) {
                Student st = new Student();
                st.setId(rs.getString(1));
                st.setName(rs.getString(2));
                st.setGpa(rs.getFloat(3));
                st.setImage(rs.getString(4));
                st.setAddress(rs.getString(5));
                st.setNotes(rs.getString(6));
                
                listStudent.add(st);
            }
            return 1;
        } catch (Exception e) {
            System.out.println("(!) Error: " + e.toString());
        }
        
        finally {
            try {
                rs.close();
                sttm.close();
                conn.close();
            } catch (Exception e) {
            }
        }
        return -1;
    }
    
    /**
     * Export Student list to text file (csv)
     */
    public int exportStudentList(String file_path) {
        try {
            if (FileProccess.writeFile(listStudent, file_path)) {
                System.out.println("(i) Export successful");
                return 1;
            }
        } catch(Exception e) {
        System.out.println("Error: " + e.toString());
        }
        return -1;
    }
    
    /**
     * Import Student list from text file (csv)
     */
    public int importStudentList(String file_path) {
        
        try{
            listStudent.clear();
            listStudent = FileProccess.readFile(file_path);

            if (listStudent.size() == 0) {
                System.out.println("(!) ERROR. Student list is currently empty");
            } else {
                System.out.println("(i) Import successful");
            }
            return 1;
        }catch(Exception e) {
            System.out.println("Error: " + e.toString());
        }
        return -1;
    }
}
