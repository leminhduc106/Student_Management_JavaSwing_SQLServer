/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentmanagement;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author lemin
 */
public class DatabaseHelper {
    public static String connectionUrl = "";
    public static Connection getDBConnect() {
        Connection conn = null;
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        }catch (Exception e) {
            System.out.println("Dont have driver yet!" + e.toString());
        }
        try {
            conn = DriverManager.getConnection(connectionUrl);
            System.out.println("(i) Connected.");
            return conn;
        }catch (Exception e) {
            System.out.println("(!) Connection Error " + e.toString());
        }
        return null;
    }
}
